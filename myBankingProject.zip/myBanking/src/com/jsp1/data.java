package com.jsp1;

public class data {

	public static void setId(String string) {
		// TODO Auto-generated method stub
		
	}

	public static void setName(String string) {
		// TODO Auto-generated method stub
		
	}

}
